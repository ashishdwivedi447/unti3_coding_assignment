var image_array=[];
var slideshow_image=document.querySelector("#image");

var url1="https://images.unsplash.com/photo-1511165403689-1e53da0499fa?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTZ8fG1vdmllJTIwcG9zdGVyfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60";
image_array.push(url1);

var url2="https://images.unsplash.com/photo-1611419010196-a360856fc42f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTV8fG1vdmllJTIwcG9zdGVyfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60";
image_array.push(url2);

var url3="https://images.unsplash.com/photo-1584448141569-69f342da535c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTN8fG1vdmllJTIwcG9zdGVyfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60";
image_array.push(url3);



var i=0;
setInterval(function(){
    if(i===image_array.length){
        i=0;
    }
  
     slideshow_image.src=image_array[i];
    i=i+1;
},1000)
